/*******************************************************************************
 * @jsname:config.js
 * @author:Bill
 * @date:2014-12-09
 * @use:妈妈100APP配置
 ******************************************************************************/
var API_HOST_URL = (location.host.indexOf("10.50")>=0||location.host.indexOf("localhost")>=0) ? "http://m10.mama100.dev" : "http://"+location.host;
if(common.device.platform == "ios") common.device.os = "iPhone OS";//如果是ios设备后台统一认为是iPhone OS

/**
 * Debug for PC or Weixin
 **/
(function(){
    if(common.support.isMobile&&!common.support.isWeixin||common.support.isMAMA100APP) return;
    common.support.isDebugMode = true;
    if(common.support.isWeixin){
        common.event.deviceready = 'DOMContentLoaded';
        common.event.viewWillAppear = 'DOMContentLoaded';
    } else {
        common.device.type = "iPhone";
        common.device.os = "iPhone OS";
        common.device.platform = "ios";
    }
    var errorDesc = navigator.userAgent.toLowerCase().indexOf("windows")>=0?"本功能需要客户端支持，请在客户端测试！":"功能受限，请升级客户端！";
    if(!navigator.exec){
        navigator.exec = function(successCallback, failCallback, pluginName, method, para){
            console.log(errorDesc+"/n 模块："+pluginName+"，方法:"+method);
        }
    }
    if(!Mama100JSBridge) return;
    var testConfig = {
        //版本号
        version : "3.1.0",

        //用户位置
        location : {
            "latitude" : 23.123873,
            "longitude" : 113.33092,
            "cityCode" : "0529"
        },

        //是否登录，OK:是,ERROR:否
        logon : "OK",

        //应用信息
        info : {
            "devid" : "A0000022DB0001",
            "accessToken" : "d79ecbb89c32f167d223749f469007a7",
            "tsno" : "201412091434401272",
            "authData" : "ATRA3FSFaDD3EdPqm8HnZDaLFXexUQuBalXqQnLO1gH+2rrVwFZKAA==",
            "versionCode" : "55"
        },

        //用户信息
        userInfo : {
            "userID" : "",
            "customerId" : "",
            "userName" : "",
            "avatar" : "",
            "mobile" : ""
        },

        login : errorDesc
    };

    Mama100JSBridge.exec = function(successCallback, failCallback, pluginName, method, para) {
        if(typeof successCallback != "function") return;
        if("App" == pluginName){
            switch(method){
                case "version" :
                    successCallback(testConfig.version);
                    break;
                case "location" :
                    successCallback(testConfig.location);
                    break;
                case "logon" :
                    successCallback(testConfig.logon);
                    break;
                case "info" :
                    successCallback(testConfig.info);
                    break;
                case "userInfo" :
                    successCallback(testConfig.userInfo);
                    break;
                case "login" :
                    alert(testConfig.login);
                    break;
                default :
                    break;
            }
        } else if("Browser" == pluginName){
            if("pop" == method){
                history.go(-para[0].level);
            }
        } else if("DataCache" == pluginName){
            if("read" == method){
                successCallback({"key":para[0].key,"content":localStorage.getItem(para[0].key)?localStorage.getItem(para[0].key):''});
            } else if("save" == method){
                localStorage.setItem(para[0].key,para[0].content);
            }
        } else if("PvStat" == pluginName){
            "record"==method&&successCallback();
        } else {
            alert(errorDesc+"\n模块："+pluginName+"，方法:"+method);
        }
    };

    Mama100JSBridge.open = function(action, para, successCallback, failCallback) {
        alert(errorDesc+"\n模块："+action);
    };

    Mama100JSBridge.openURL = function(url,isOpenNewWindow){
        if(!isOpenNewWindow){
            window.location.href = url;
        } else {
            window.open(url);
        }
    }
})();