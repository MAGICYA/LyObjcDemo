/*******************************************************************************
 * @jsname:mama100jsbridge.js
 * @author:liangweixiong
 * @date:2014-06-06
 * @use:妈妈100客户端js接口桥，负责和app通信与交互
 ******************************************************************************/

var Mama100JSBridge = new _Mama100JSBridge();

function _Mama100JSBridge() {

};

/**
 * 打开执行动作
 * 
 * @param action
 *            动作类型:该参数告诉客户端html5要调用的动作类型，客户端根据相关的动作类型执行相应的逻辑
 * @param para
 *            动作参数: 参数格式为Json，一来是方便html5编写参数，二来是方便客户端进行对象转换
 * @param successCallback
 *            成功回调函数
 * @param failCallback
 *            失败回调函数
 */
_Mama100JSBridge.prototype.open = function(action, para, successCallback,
		failCallback) {

	if (this.isIos()) {
		navigator.open(action, para, successCallback, failCallback);
	} else {
		_tempSuccessCallback = successCallback;
		_tempFailCallback = failCallback;
		window.mama100.open(action, para == undefined ? {} : JSON
				.stringify(para), '_successCallback', '_failCallback');
	}
};

/**
 * 运行执行动作
 * 
 * @param successCallback
 *            成功回调函数
 * @param failCallback
 *            失败回调函数
 * @param pluginName
 *            插件名称
 * @param method
 *            插件方法
 * @param para
 *            参数
 */
_Mama100JSBridge.prototype.exec = function(successCallback, failCallback,
		pluginName, method, para) {
	if (this.isIos()) {
		navigator.exec(successCallback, failCallback, pluginName, method, para);
	} else {
		/*_tempSuccessCallback = successCallback;
		_tempFailCallback = failCallback;
		window.mama100.exec('_successCallback', '_failCallback', pluginName,
				method, para == undefined ? {} : JSON.stringify(para));*/
        var t = Date.now(),
            sc = '_successCallback_'+method+'_'+t,
            fc = '_failCallback_'+method+'_'+t;
        creatFn(sc,fc,successCallback,failCallback);
        window.mama100.exec(sc, fc, pluginName,
            method, para == undefined ? {} : JSON.stringify(para));
	}
};

/**
 * 判断是否是Ios手机
 * 
 * @returns {Boolean}
 */
_Mama100JSBridge.prototype.isIos = function() {
	if ((navigator.userAgent.match(/iPhone|iPod/i))
			|| (navigator.userAgent.match(/iPod/i))) {
		return true;
	} else {
		return false;
	}
};

/**
 * 打开新窗口
 *
 * @param url 页面url地址
 */
_Mama100JSBridge.prototype.openURL = function(url) {
    var urlArray = [{ "url":url, " uiCode":"1"}];
    if (this.isIos()) {
        navigator.exec(function(result){}, function(code){}, "Browser", "open", urlArray);
    } else {
        _tempSuccessCallback = function(result){};
        _tempFailCallback = function(code){};
        window.mama100.exec('_successCallback', '_failCallback', "Browser", "open", JSON.stringify(urlArray));
    }
};

// 临时变量，保存回调函数
var _tempSuccessCallback = null;
var _tempFailCallback = null;
/**
 * 成功回调函数，供android用
 * 
 * @param result
 */
function _successCallback(result) {
	if (_tempSuccessCallback != null && _tempSuccessCallback != undefined) {
		_tempSuccessCallback(result);
	}
}

/**
 * 失败回调函数,供android用
 * 
 * @param code
 */
function _failCallback(code) {
	if (_tempFailCallback != null && _tempFailCallback != undefined) {
		_tempFailCallback(code);
	}
}

function creatFn(sc,fc,successCallback,failCallback){
    window[sc] = successCallback;
    window[fc] = failCallback;
}

function loadCordova() {
    var path = "",
        scripts = document.getElementsByTagName('script'),
        term = 'mama100jsbridge';
    for (var n = scripts.length-1; n>-1; n--) {
        var src = scripts[n].src;
        if (src.indexOf(term) !=-1 ) {
            path = src.split(term)[0];
            break;
        }
    }
    document.write(unescape("%3Cscript src=\""+path+"cordova.min.js\"%3E%3C/script%3E"));
}

Mama100JSBridge.isIos()&&loadCordova();