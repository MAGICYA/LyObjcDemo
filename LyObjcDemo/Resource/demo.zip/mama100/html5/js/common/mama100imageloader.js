/**
 * @version v1.0.0 - 2014-12-16
 * @author david.liang
 * @use 妈妈100与原生接口实现的图片加载器 (非重要图片不要使用该功能）
 */
angular.module('mama100-imageloader', []);
angular.module('mama100-imageloader').directive('cacheImg', function() {
	return {
		restrict : 'A',
		replace : true,
		scope : {
			cacheImgValue : '=',
			cacheImgBg : '='
		},
		link : function(scope, elem, attrs) {
			console.log(': link => '+scope.cacheImgValue);
			elem[0].imgBgHiddenAttr=scope.cacheImgBg;
			elem[0].failCountHiddenAttr=0;
			if(scope.cacheImgValue!=undefined&&scope.cacheImgValue!='')
			 _loadImage(elem[0], scope.cacheImgValue);
			scope.$watch('cacheImgValue', function(newValue, oldValue) {
				if (newValue) {
					console.log(': newValue => ' + newValue+",oldValue=>"+oldValue);
					if(newValue!=undefined&&newValue!='')
					_loadImage(elem[0],newValue);
					// scope.$apply();
				}
			});
			/*
			 * compile : function(tElem, tAttrs) { // tElem[0].src =
			 * tAttrs.cacheImgSrc; _loadImage(tElem[0], tAttrs.cacheImgSrc);
			 * console.log('图片地址: ' + tAttrs.cacheImgSrc); console.log(':
			 * compile => ' + tElem.html()); return { pre : function(scope,
			 * iElem, iAttrs) { console.log(': pre link => ' + iElem.html()); },
			 * post : function(scope, iElem, iAttrs) { console.log(': post link => ' +
			 * iElem.html()); if (angular.isDefined(iAttrs.cacheImgSrc)) {
			 * scope.$watch('cacheImgSrc', function(newValue) {
			 * scope.cacheImgSrc = newValue; console.log(': newValue => ' +
			 * newValue); }); } } };
			 */
		}
	};
});

var _imgLoadingArray = new Array();

function _loadImage(imgElem, imageUrl) {
	if(imageUrl==undefined||imageUrl=='')
	{
		return;
	}
	/*
	 * imgElem.src = imageUrl; return;
	 */
	// 判断是否是相对地址，如果是相对地址，直接使用src方式加载
	if(!imageUrl.startWith('http'))
	{
        if(imgElem.tagName.toUpperCase() == "IMG"){
            imgElem.src=imageUrl;
        } else {
            imgElem.style.backgroundImage="url("+imageUrl+")";
        }
		return;
	}
	//在android和调试模式下，使用img的src属性加载（因为这二种情况都不支持通过接口图片加载)
	if (!common.support.isDebugMode&&common.device.platform!='android') {
		imgElem.imgSrcHiddenAttr = imageUrl;
		_imgLoadingArray.push(imgElem);
		Mama100JSBridge.exec(function(result){
			_onCacheImageCallBack(result);
		}, function(errorObject) {
			_onCacheImageFailCallBack(errorObject);
		}, "Platform", "loadImage", [ {
			"imageUrl" : imageUrl
		} ]);
	} else {
		if(imgElem.imgBgHiddenAttr==true)
		{
			imgElem.style.backgroundImage="url("+imageUrl+")";
		}
		else
		{
			imgElem.src = imageUrl;
		}
	}

}


var isDoingCallback = false;
/**
 * 图片加载成功处理
 * 
 * @param result
 */
function _onCacheImageCallBack(result) {
	isDoingCallback = true;
	for ( var i = _imgLoadingArray.length - 1; i >= 0; i--) {
		var img=_imgLoadingArray[i];
		// alert("imgUrl:"+img.imgSrcHiddenAttr);
		if (img.imgSrcHiddenAttr == result.imageUrl) {
			if(result.imageBase64==undefined||result.imageBase64==''||result.imageBase64==null)
			{
				continue;
			}
			var imageType=_getImageType(result.imageUrl);
			var base64= 'data:image/'+imageType+';base64,' + result.imageBase64;
			if(img.imgBgHiddenAttr==true)
			{
				img.style.backgroundImage="url('"+base64+"')";
			}
			else
			{
				 img.src =base64;
			}
			// 删除原来的元素
			_imgLoadingArray.remove(i);
		}
	}
	isDoingCallback = false;
}

/**
 * 图片加载失败处理
 * 
 * @param result
 */
function _onCacheImageFailCallBack(result)
{
	// alert('图片加载失败:'+result.imageUrl);
	console.log("失败图片地址:" + result.imageUrl);
	console.log("失败信息:" + result.errorMsg);
	// 如果加载失败,则在加载列表中清除
	for ( var i = _imgLoadingArray.length - 1; i >= 0; i--) {
		var img=_imgLoadingArray[i];
		if (img.imgSrcHiddenAttr == result.imageUrl) {
			_imgLoadingArray.remove(i);
		}
	}
}

Array.prototype.remove = function(dx) {
	if (isNaN(dx) || dx > this.length) {
		return false;
	}
	for ( var i = 0, n = 0; i < this.length; i++) {
		if (this[i] != this[dx]) {
			this[n++] = this[i];
		}
	}
	this.length -= 1;
};

String.prototype.startWith=function(s){
	  if(s==null||s==""||this.length==0||s.length>this.length)
	   return false;
	  if(this.substr(0,s.length)==s)
	     return true;
	  else
	     return false;
	  return true;
};

String.prototype.endWith = function (param) {
    if (param == null || param == "" || this.length == 0 || param.length > this.length) { 
      return false; 
    } 
    if (this.substring(this.length - param.length) == param) { 
      return true; 
    } else { 
      return false; 
    } 
};


function _getImageType(imageUrl)
{
	if(imageUrl.endWith('jpg'))
	{
		return "jpeg";
	}
	else if(imageUrl.endWith('png'))
	{
		return "png";
	}
	else if(imageUrl.endWith('gif'))
	{
		return "gif";
	}
	else if(imageUrl.endWith('webp'))
	{
		return "webp";
	}
	return "";
}

/**
 * 定时检查去取图片，解决ios中
 */
window.setInterval(function() {
	if (!isDoingCallback) {
		for ( var i = _imgLoadingArray.length - 1; i >= 0; i--) {
			var img = _imgLoadingArray[i];
			img.failCountHiddenAttr++;
			// 重试200次，大概是20秒左右之后从加载列表删除
			if(img.failCountHiddenAttr>200)
			{
				_imgLoadingArray.remove(i);
			}
			else
			{
			   Mama100JSBridge.exec(function(result) {
				_onCacheImageCallBack(result);
			   }, function(errorObject) {
				 _onCacheImageFailCallBack(errorObject);
			     }, "Platform", "loadImage", [ {
				"imageUrl" : img.imgSrcHiddenAttr
			    } ]);
			}

		}
	}
}, 300);