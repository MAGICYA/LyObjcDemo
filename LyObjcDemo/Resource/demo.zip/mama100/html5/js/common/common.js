/*******************************************************************************
 * @jsname:common.js
 * @author:Bill
 * @date:2014-12-10
 * @use:妈妈100APP常用方法
 ******************************************************************************/

var common = window.common = {

    //批量扩展common的方法或属性
    extend : function(){
        var options = arguments[0];
        for(var i in options){
            this[i] = options[i];
        }
    }
};

//设备类型
common.device = (function(){
    var dev = {type:"noMobile",os:"window",version:"0",platform:"window"},
        ua = navigator.userAgent,
        iPad = ua.match(/(iPad).*OS\s([\d_]+)/),
        iPod = !iPad && ua.match(/(iPod).*OS\s([\d_]+)/),
        iPhone = !iPad && !iPod && ua.match(/(iPhone\sOS)\s([\d_]+)/),
        android = !iPad && !iPod && !iPhone && ua.match(/(Android)\s([\d\.]+)/);
    if (iPad) {
        dev.type = "iPad";
        dev.version = iPad[2].replace(/_/g, ".");
        dev.os = "iPad OS";
        dev.platform = "ios";
    }
    if (iPod) {
        dev.type = "iPod";
        dev.version = iPod[2].replace(/_/g, ".");
        dev.os = "iPod OS";
        dev.platform = "ios";
    }
    if (iPhone) {
        dev.type = "iPhone";
        dev.version = iPhone[2].replace(/_/g, ".");
        dev.os = "iPhone OS";
        dev.platform = "ios";
    }
    if (android) {
        dev.type = "android";
        dev.version = android[2];
        dev.os = "android";
        dev.platform = "android";
    }
    return dev;
})();

//支持特性检测
common.support = {
    //是否是移动设备
    isMobile : common.device.type != 'noMobile',
    //是否是微信
    isWeixin : navigator.userAgent.toLowerCase().indexOf("micromessenger") >= 0,
    //是否是妈妈100APP
    isMAMA100APP : navigator.userAgent.toLowerCase().indexOf("mama100") >= 0,
    //是否是调试模式
    isDebugMode : false,
    //是否运行在WiFi/3G等网络
    /*connection : function(){
        return window.navigator.connection;
    },*/
    //网络连接状态
    online : function(){
        return window.navigator.onLine;
    }
};

if(common.support.isMAMA100APP) {
    //无法判断是否移动设备,但确定是mama100客户端,则认为是安卓设备,兼容android设备厂商修改userAgent的问题
    if(!common.support.isMobile){
        common.device = {
            type : "android",
            version : "0",
            os : "android",
            platform : "android"
        }
    }
    //mama100客户端版本号
    common.mama100AppVersion = navigator.userAgent.toLowerCase().split("mama100;")[1].split(";")[0]
}

common.event = (function(){
    return {
        start : common.support.isMobile ? 'touchstart' : 'mousedown',
        move : common.support.isMobile ? 'touchmove' : 'mousemove',
        end : common.support.isMobile ? 'touchend' : 'mouseup',
        deviceready : common.support.isMobile ? 'deviceready' : 'DOMContentLoaded',
        viewWillAppear : common.support.isMobile ? 'viewWillAppear' : 'DOMContentLoaded'
    }
})();

//扩展方法
common.extend({
    /**
     * APP版本检测,版本较低，运行callback 说明：ios依赖于cordova.js
     * @method validateOldApp
     * @return true：旧版app； false：新版app
     */
    validateOldApp : function() {
        if ((navigator.userAgent.match(/iPhone/i))
            || (navigator.userAgent.match(/iPod/i))) {// ios
            var version = undefined;
            navigator.exec(function(result) {// 新版
                version = result;
                version = version.replace(/\./g, "");
                if (version.length == 2) {
                    version = version + "0";
                }
                if (parseInt(version) <= 250) {// 低于2.5版本
                    alert("请更新到最新版本app！");
                    return true;
                } else {
                    return false;
                }

            }, function(code) {
                alert(code);
            }, "App", "version", {});

            setTimeout(function() {
                if (version == undefined) {// 旧版
                    alert("请更新到最新版本app！");
                    return true;
                } else {
                    return false;
                }
            }, 1500);

        } else {// 安卓
            if (window.mama100 == undefined) {// 旧版
                alert("请更新到最新版本app！");
                return true;
            } else {
                return false;
            }

        }
    },
    /**
     * 获取参数值
     *
     * @method getQueryString
     * @param {string} name 参数名称
     * @return 参数值
     */
    getQueryString : function (name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        var context = "";
        if (r != null)
            context = r[2];
        reg = null;
        r = null;
        return context == null || context == "" || context == "undefined" ? "" : context;
    },
    
    getRandomNum : function (Min,Max)
	{   
		var Range = Max - Min;   
		var Rand = Math.random();   
		return(Min + Math.round(Rand * Range));   
	},   
	
	getTsno : function (){
		return new Date().getTime()+common.getRandomNum(1000, 9999);
	},
    
    /**
     * 获取url hash值
     * */
    getHashValue : function (key) {
    	var value = location.hash.match(new RegExp(key+'=([^&]*)'));
    	 return value==undefined||value==null?"":value[1];
    },

    /**
     * @author david.liang 版本比较
     * @param version1
     * @param version2
     * @return 0:表示相等,1表示大于，-1表示小于
     */
    compareVersion : function(version1, version2){
        var version1Array = [];
        version1Array = version1.split(".");

        var version2Array = [];
        version2Array = version2.split(".");

        var version1Value = 0, version2Value = 0;
        version1Value = version1Array[0] * 100 + version1Array[1] * 10 + version1Array[2];
        version2Value = version2Array[0] * 100 + version2Array[1] * 10 + version2Array[2];
        if (version1Value == version2Value) {
            return 0;
        } else {
            return (version1Value - version2Value > 0) ? 1 : -1;
        }
    },

    /**
     * 获取字符串字节长度
     * @param chars 字符
     * @return sum 字符总数
     */
    charsCalculate : function(chars){
        var sum = 0;
        for (var i=0; i<chars.length; i++)
        {
            var c = chars.charCodeAt(i);
            if ((c >= 0x0001 && c <= 0x007e) || (0xff60<=c && c<=0xff9f))
            {
                sum++;
            } else {
                sum+=2;
            }
        }
        return sum;
    },

    /**
     * 截取长度内的字符串(以字节为单位)
     * @param chars 字符
     * @param len 字符长度
     * @param isShowEllipsis 超过长度时是否显示省略号
     * @return chars 字符串
     */
    charsSubstr : function(chars,len, isShowEllipsis){
        if(this.charsCalculate(chars)<=len){
            return chars;
        } else {
            var newChars = "",sum = 0;
            for (var i=0; i<chars.length; i++){
                var c = chars.charCodeAt(i);
                if ((c >= 0x0001 && c <= 0x007e) || (0xff60<=c && c<=0xff9f)){
                    sum++;
                } else {
                    sum+=2;
                }
                if(sum<len){
                    newChars += chars[i];
                } else if(sum==len){
                    newChars += chars[i];
                    break;
                }else if(sum>len){
                    break;
                }
            }
            return isShowEllipsis ? newChars + "..." : newChars;
        }
    },
    
    //小数加减乘除
    calculate : {
        /**
         * 除法
         * @param arg1 被除数
         * @param arg2 除数
         * @return number
         */
        div: function (arg1, arg2) {
            var t1 = 0, t2 = 0, r1, r2;
            try {
                t1 = arg1.toString().split(".")[1].length
            } catch (e) {
            }
            try {
                t2 = arg2.toString().split(".")[1].length
            } catch (e) {
            }
            r1 = Number(arg1.toString().replace(".", ""));
            r2 = Number(arg2.toString().replace(".", ""));
            return this.mul((r1 / r2), Math.pow(10, t2 - t1));
        },
        /**
         * 乘法
         * @param arg1 被乘数
         * @param arg2 乘数
         * @return number
         */
        mul: function (arg1, arg2) {
            var m = 0, s1 = arg1.toString(), s2 = arg2.toString();
            try {
                m += s1.split(".")[1].length
            } catch (e) {
            }
            try {
                m += s2.split(".")[1].length
            } catch (e) {
            }
            return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m);
        },
        /**
         * 加法
         * @param arg1 被加数
         * @param arg2 加数
         * @return number
         */
        add: function (arg1, arg2) {
            var r1, r2, m;
            try {
                r1 = arg1.toString().split(".")[1].length
            } catch (e) {
                r1 = 0
            }
            try {
                r2 = arg2.toString().split(".")[1].length
            } catch (e) {
                r2 = 0
            }
            m = Math.pow(10, Math.max(r1, r2));
            return (arg1 * m + arg2 * m) / m;
        },
        /**
         * 减法
         * @param arg1 被减数
         * @param arg2 减数
         * @return number
         */
        sub: function (arg1, arg2) {
            var r1, r2, m, n;
            try {
                r1 = arg1.toString().split(".")[1].length
            } catch (e) {
                r1 = 0
            }
            try {
                r2 = arg2.toString().split(".")[1].length
            } catch (e) {
                r2 = 0
            }
            m = Math.pow(10, Math.max(r1, r2));
            n = (r1 >= r2) ? r1 : r2;
            return +((arg1 * m - arg2 * m) / m).toFixed(n);
        }
    },

    /**
     * 日期格式化
     * @param arg 时间,如:2015-08-10 或 2015-08-10 08:00:05 或 2015-08-10 08:00:05 或 毫秒:1439198524890
     * @return {object}
     */
    dateFormat: function(arg){
        var dateObj,year,month,date,hours,minutes,seconds,milliseconds,ms;
        if(typeof arg == "object"&&arg.getDate){
            dateObj = arg;
        } else if(/\d{4}[\-\/]\d{2}[\-\/]\d{2}( \d{2}\:\d{2}\:\d{2})?/.test(arg)||/^\d+$/.test(arg)){
            arg = (arg+"").replace(/\-/g,"/");
            dateObj = new Date(arg.indexOf("/")>=0?arg:+arg);
        } else {
            return undefined;
        }
        year = dateObj.getFullYear();
        month = dateObj.getMonth()+1;
        date = dateObj.getDate();
        hours = dateObj.getHours();
        minutes = dateObj.getMinutes();
        seconds = dateObj.getSeconds();
        milliseconds = dateObj.getMilliseconds();//当前毫秒
        ms = dateObj.getTime();//1970年1月1日至今的总毫秒数
        return {
            fullDate: year+"-"+(month < 10 ? "0" + month : month) + "-" + (date < 10 ? "0" + date : date) + " " + (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds < 10 ? "0" + seconds : seconds),
            year: year,
            month: month,
            date: date,
            hours: hours,
            minutes: minutes,
            seconds: seconds,
            milliseconds: milliseconds,
            ms: ms
        }
    }
});

String.prototype.replaceAll = function (search, repText){
	return this.split(search).join(repText);
		}