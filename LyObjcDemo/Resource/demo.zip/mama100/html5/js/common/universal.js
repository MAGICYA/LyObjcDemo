"use strict";
/* get url argument from location or from a given string
 * http://163.com:2344/testpage.php?a=123&b=zzz
 * "http://123.com/?a=sss".toURLParameter("a") == "sss" 
 * "http://123.com/?a=sss".toURLParameter().a == "sss"
 * if you want current page URLParameter,use location.toURLParameter
 */
String.prototype.toURLParameter = function (name){	
    var match,
    urlParams = {},
    pl     = /\+/g,
    search = /([^&=]+)=?([^&]*)/g,
    decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); };
while (match = search.exec(this)){urlParams[decode(match[1])] = decode(match[2]);}
return typeof(name)==="undefined"?urlParams:urlParams[name];
		}

location.urlParameter=function(name){
	 return location.search.substring(1).toURLParameter(name);
		}
/* repleace all text with given text from a string
 * 
 */
String.prototype.replaceAll = function (search, repText){
	return this.split(search).join(repText);
		}
String.prototype.bool=function(){
	return this["0"]+this["1"]+this["2"]+this["3"]==="true";
}
function localData(key,value){
	var loadData=typeof(value)=="undefined",
		returnData;	
	if(loadData){
		//load
		returnData=localStorage.getItem(key);
		if(returnData==null){return returnData;}//return if this key is not storge yet
		returnData=(returnData.substr(0,1)=="{"&&returnData.substr(-1,1)=="}")||(returnData.substr(0,1)=="["&&returnData.substr(-1,1)=="]")?JSON.parse(returnData):returnData;
	}else{
		//save
		returnData=localStorage.setItem(key,typeof(value)=="object"?JSON.stringify(value):value);
	}
	return returnData;
}
function globalPopup(id){
	
	document.querySelector("html").classList.remove("globalPopup");
	//$("html").removeClass("globalPopup");
	for(var a=0,b=document.querySelectorAll(".popupRoot>*");a<b;a++){
		b[a].classList.remove("active");
	}
	//$(".popupRoot>*").removeClass("active");
	if(typeof(id)==="undefined"||id==""){return}
		document.querySelector("html").classList.add("globalPopup");
		//$("html").addClass("globalPopup");
		document.querySelector("#"+id).classList.add("active");
		//$("#"+id).addClass("active");
}