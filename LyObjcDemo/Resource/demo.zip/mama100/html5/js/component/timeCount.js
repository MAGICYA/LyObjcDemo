
/**
 * @ name 倒计时对象
 * @ desc:
 * 1.可设置多个倒计时,重复使用TimeCount.create即可
 * 2.可设置一个倒计时用在类名相同的标签上,设置参数selector为类名(标签类名)即可
 * 3.可设置开始时间,设置参数options.startTime即可
 * 4.可直接传入倒计时毫秒数,直接倒计,不用设置开始时间与结束时间,使用方法：endTime传入倒计毫秒总数,options.endTimeIsRemainingMS=true
 * 5.可设置渲染的模板,设置参数options.template,可设为对象或字符串,设为对象时必须同时设置gtDay,ltDayGtHour,ltHour这3个模板
 *     如,
 *     设置不可变模板:template = "<span class='timeDay'>[[dd]]</span>天<span class='timeHour'>[[hh]]</span>:<span class='timeMinute'>[[mm]]</span>:<span class='timeSecond'>[[ss]]</span>"
 *     设置可变模板：
 *     template:{
 *          gtDay: "<span>[[dd]]</span>天",//大于等于1天时显示此模板
 *          ltDayGtHour: "<span>[[hh]]</span>小时",//小于1天并且大于等于1小时显示此模板
 *          ltHourGtMinute: "<span>[[mm]]</span>分钟",//小于1小时并且大于等于1分钟显示此模板
 *          ltMinute: "<span>[[mm]]</span>:<span>[[ss]]</span>"//小于1分钟显示此模板
 *      },
 *     说明：天：[[d]],[[D]],小于10时前面不加0;[[dd]],[[DD]]小于10时前面加0
 *     小时：[[h]],[[H]],,小于10时前面不加0;[[hh]],[[HH]]小于10时前面加0
 *     分钟：[[m]],[[M]],,小于10时前面不加0;[[mm]],[[MM]]小于10时前面加0
 *     秒：[[s]],[[S]],,小于10时前面不加0;[[ss]],[[MM]]小于10时前面加0
 * 6.可销毁单个倒计时,TimeCount[name].destroy(),TimeCount.name.destroy()或TimeCount.destroy(name)
 * 7.也可一次销毁所有倒计时,TimeCount.destroyAll()
 * @ author Bill
 * @ date 2015-7-2
 * e.g.:
 * TimeCount.create("timeName","#tagId","2015-07-02 08:00:05",{
 *      startTime: "2015-07-02 08:00:00",
 *      template:"<p><span class='timeDay'>[[dd]]</span>天<span class='timeHour'>[[hh]]</span>:<span class='timeMinute'>[[mm]]</span>:<span class='timeSecond'>[[ss]]</span></p>",
 *      endCountCallBack: function(){
 *          alert("end");
 *      }
 * });
 * TimeCount.create("timeName","#tagId","2015-07-02 09:00:00",{
 *      startTime: "2015-07-02 07:59:57",
 *      template:{
 *          gtDay: "<span>[[dd]]</span>天",
 *          ltDayGtHour: "<span>[[hh]]</span>小时",
 *          ltHourGtMinute: "<span>[[mm]]</span>分钟",
 *          ltMinute: "<span>[[mm]]</span>:<span>[[ss]]</span>"
 *      },
 *      endCountCallBack: function(){
 *          alert("end");
 *      }
 * });
 */
(function(context){
    context.TimeCount = {
        /**
         * 创建倒计时
         * @ name 倒计时名称,必须
         * @ selector 标签选择器或dom对象,必须
         * @ endTime 结束时间,必须,格式:2015-07-02 08:00:05 或 2015/07/02 08:00:05 或 毫秒
         * @ options 参数配置,可选,startTime:开始时间,默认为当前时间,endTimeIsRemainingMS:是否endTime当成剩余毫秒总数直接倒计,template:倒计时显示模板,endCountCallBack:倒计时结束回调
         */
        create: function(name, selector, endTime, options){

            if(!/\d{4}[\-\/]\d{2}[\-\/]\d{2} \d{2}\:\d{2}\:\d{2}/.test(endTime)&&!/^\d+$/.test(endTime)){
                alert("时间格式不正确");
                return;
            }

            if(typeof TIMEConstructor == "function") {
                this[name] = new TIMEConstructor(name,selector,endTime,options);
                return;
            }

            var _this = this;

            /**
             * 类：倒计时
             * @ _selector 标签选择器或dom对象
             * @ _endTime 结束时间
             * @ _options 参数配置,可选,startTime:开始时间,默认为当前时间,endTimeIsRemainingMS:是否_endTime当成剩余毫秒数直接倒计,template:倒计时显示模板,endCountCallBack:倒计时结束回调
             */
            TIMEConstructor = function(_name,_selector, _endTime, _options){
                _options = _options || {};
                this.options = {
                    name: _name,
                    selector: typeof _selector == "object"?_selector:document.querySelectorAll(_selector),
                    endTime: _endTime,
                    startTime: _options.startTime||null,
                    endTimeIsRemainingMS: _options.endTimeIsRemainingMS||false,
                    template: _options.template||"<span>[[dd]]</span> <span>[[hh]]</span>:<span>[[mm]]</span>:<span>[[ss]]</span>",
                    endCountCallBack: _options.endCountCallBack||null
                };
                if(!this.options.selector.length) this.options.selector = [this.options.selector];
                if(!this.options.endTimeIsRemainingMS){
                    var endMS = /^\d+$/.test(this.options.endTime)?+this.options.endTime:new Date(this.options.endTime.replace(/\-/g,"/")).getTime(),
                        startMS = !this.options.startTime?Date.now():/^\d+$/.test(this.options.startTime)?+this.options.startTime:new Date(this.options.startTime.replace(/\-/g,"/")).getTime();
                    if((this.remainingMS=endMS-startMS)<=0){
                        alert("时差不能小于等于0");
                        return;
                    }
                } else {
                    if((this.remainingMS=+this.options.endTime)<=0){
                        alert("时差不能小于等于0");
                        return;
                    }
                }
                this.render();
                this.auto();
            };

            /**
             * 公有方法：渲染倒计时
             */
            TIMEConstructor.prototype.render = function(){
                var day = Math.floor(this.remainingMS / (3600000*24)),
                    hour = Math.floor((this.remainingMS - 3600000*24*day) / 3600000),
                    minute = Math.floor((this.remainingMS - 3600000*24*day - 3600000 * hour) / 60000),
                    second = Math.floor((this.remainingMS - 3600000*24*day - 3600000 * hour - 60000 * minute) / 1000),
                    showHour = hour >= 10 ? hour : "0" + hour,
                    showMinute = minute >= 10 ? minute : "0" + minute,
                    showSecond = second >= 10 ? second : "0" + second,
                    tagLen = this.options.selector.length;
                if(typeof this.options.template == "string"){
                    template = this.options.template;
                } else {
                    if(day>=1){
                        template = this.options.template["gtDay"];
                    } else if(hour>=1){
                        template = this.options.template["ltDayGtHour"];
                    } else if(minute>=1){
                        template = this.options.template["ltHourGtMinute"];
                    } else {
                        template = this.options.template["ltMinute"];
                    }
                }
                if(!template) return;
                for(var i = 0;i<tagLen;i++){
                    this.options.selector[i].innerHTML = template
                        .replace(/\[\[(d|D){1}\]\]/,parseInt(day))
                        .replace(/\[\[(d|D){2,}\]\]/,day)
                        .replace(/\[\[(h|H){1}\]\]/,parseInt(+showHour))
                        .replace(/\[\[(h|H){2,}\]\]/,showHour)
                        .replace(/\[\[(m|M){1}\]\]/,parseInt(+showMinute))
                        .replace(/\[\[(m|M){2,}\]\]/,showMinute)
                        .replace(/\[\[(s|S){1}\]\]/,parseInt(+showSecond))
                        .replace(/\[\[(s|S){2,}\]\]/,showSecond);
                }
            };

            /**
             * 公有方法：倒计
             */
            TIMEConstructor.prototype.auto = function(){
                var _this = this;
                this.timer = setTimeout(function () {
                    if (_this.remainingMS > 1000) {
                        _this.remainingMS -= 1000;
                        _this.render();
                        _this.auto();
                    } else {
                        _this.remainingMS = 0;
                        _this.timer = null;
                        _this.render();
                        if(typeof _this.options.endCountCallBack == "function") _this.options.endCountCallBack();
                    }
                }, 1000);
            };

            /**
             * 公有方法：销毁倒计时
             */
            TIMEConstructor.prototype.destroy = function(){
                var tagLen = this.options.selector.length;
                clearTimeout(this.timer);
                this.timer = null;
                for(var i = 0;i<tagLen;i++){
                    this.options.selector[i].innerHTML = '';
                }
                delete _this[this.options.name];
            };

            //TimeCount存储倒计时对象
            this[name] = new TIMEConstructor(name,selector,endTime,options);
        },

        /**
         * 销毁指定的倒计时
         * @ key 倒计时对象名称
         */
        destroy: function(key){
            var timeObj = this[key],
                tagLen = timeObj.options.selector.length;
            clearTimeout(timeObj.timer);
            timeObj.timer = null;
            for(var i = 0;i<tagLen;i++){
                timeObj.options.selector[i].innerHTML = '';
            }
            delete this[key];
        },

        /**
         * 销毁所有倒计时
         */
        destroyAll: function(){
            for(var key in this){
                if(this[key].options){
                    this.destroy(key);
                }
            }
        }
    };
})(window);